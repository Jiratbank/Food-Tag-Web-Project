import { useEffect, useState, useContext } from "react";
import axios from "axios";
import { AuthContext } from "../context/AuthContext";

const ReportTable = () => {
  const { token, role } = useContext(AuthContext);
  const [reports, setReports] = useState([]);
  const [editingReport, setEditingReport] = useState(null);
  const [form, setForm] = useState({ title: "", description: "", category: "", status: 0 });
  const [filterCategory, setFilterCategory] = useState("");

  const [status, setStatus] = useState("idle"); // "idle" | "loading"

  // ✅ หมวดหมู่แบบ fixed
  const categories = [
    { id: "", name: "ทั้งหมด" },
    { id: "บั๊ก", name: "บั๊ก" },
    { id: "ปัญหาหน้าจอ/UI", name: "ปัญหาหน้าจอ/UI" },
    { id: "ประสิทธิภาพ", name: "ประสิทธิภาพ" },
    { id: "อื่น", name: "อื่นๆ" },
  ];

  useEffect(() => {
    if (role === "1") fetchReports();
  }, [role]);

  const fetchReports = async () => {
    setStatus("loading");
    try {
      const res = await axios.get("http://localhost:3000/api/reports", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setReports(res.data);
      setStatus("idle");
    } catch (err) {
      console.error("Error fetching reports:", err.response?.data || err.message);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("คุณต้องการลบ Report นี้หรือไม่?")) {
      try {
        await axios.delete(`http://localhost:3000/api/reports/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        fetchReports();
      } catch (err) {
        console.error("Delete error:", err);
      }
    }
  };

  const handleEdit = (report) => {
  setEditingReport(report._id);
  setForm({
    report_id: report.report_id,
    report_category: report.report_category,
    report_detail: report.report_detail,
    report_status: report.report_status,
    created_by_username: report.created_by_username,
    report_createdAt: report.report_createdAt,
  });
};


  const handleAdd = () => {
    setEditingReport("new");
    setForm({ report_category: "", report_detail: "", report_status: 0 });
  };

  const handleSave = async () => {
    if (!form.report_category) {
      alert("กรุณาเลือกหมวดหมู่ก่อนบันทึก!");
      return; // ไม่ส่ง request
    }
    try {
      if (editingReport === "new") {
        await axios.post("http://localhost:3000/api/reports", form, {
          headers: { Authorization: `Bearer ${token}` },
        });
      } else {
        await axios.put(`http://localhost:3000/api/reports/${editingReport}`, form, {
          headers: { Authorization: `Bearer ${token}` },
        });
      }
      setEditingReport(null);
      fetchReports();
    } catch (err) {
      console.error("Save error:", err.response?.data || err.message);
    }
  };

  // ✅ Filter reports ตามหมวดหมู่
  const filteredReports = filterCategory
    ? reports.filter((r) => r.report_category === filterCategory)
    : reports;

  return (
    <div className="rounded">
      <h2 className="text-2xl font-bold">รายงานที่แจ้งมา</h2>
      {status === "loading" && (
        <div className="text-center">
          <span className="loading loading-lg loading-spinner"></span>
        </div>
      )}
      

      {status === "idle" && !reports.length && (
        <div className="text-center">ไม่มีข้อมูล</div>
      )}

      {/* Dropdown filter ด้านบน */}
      <div className="flex justify-between items-center mb-4 mt-2">
        <button onClick={handleAdd}
        className="btn btn-outline">
        + เพิ่ม Report (Just Test ไม่มีจริงตอน release)</button>
        <div className="flex items-center space-x-2">
        <label className="whitespace-nowrap font-bold">
          หมวดหมู่ปัญหา :{" "}
          <select className="select w-48"
          value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)}>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </label>
      </div>
      </div>
      

      {/* ตาราง */}
      <table className="table table-s w-full rounded-box bg-base-100">
        <thead>
          <tr>
            <th>Report ID</th>
            <th>หมวดหมู่</th>
            <th>รายละเอียด</th>
            <th>ผู้เเจ้ง</th>
            <th>วันที่แจ้ง</th>
            <th>สถานะ</th>
            <th>จัดการ</th>
          </tr>
        </thead>
        <tbody>
          {filteredReports.length === 0 ? (
            <tr>
              <td colSpan="7" className="text-center py-4">
                ไม่พบข้อมูล
              </td>
            </tr>
          ) : (
            filteredReports.map((r) => (
              <tr key={r._id}>
                <td>{r.report_id}</td>
                <td>{r.report_category}</td>
                <td>{r.report_detail}</td>
                <td>{r.created_by_username || r.created_by}</td>
                <td>{new Date(r.report_createdAt).toLocaleDateString("th-TH")}</td>
                <td>{r.report_status === 1 ? "แก้แล้ว" : "รอดำเนินการ"}</td>
                <td>
                  <button onClick={() => handleEdit(r)} 
                    className="btn btn-outline btn-sm btn-info">
                    แก้ไข</button>
                  <> </>
                  <button onClick={() => handleDelete(r._id)}
                    className="btn btn-outline btn-sm btn-error">
                    ลบ</button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
      <div className="mt-2 text-sm text-right">
       จำนวนทั้งหมด: {filteredReports.length} รายการ
      </div>

      {/* Modal Add/Edit */}
      {editingReport && (
  <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 text-gray-900">
    <div className="bg-gray-100 rounded-lg shadow-lg p-6 w-[450px]">
      <h3 className="text-xl font-bold mb-3">
        {editingReport === "new" ? "เพิ่ม Report" : "รายละเอียด & แก้ไขสถานะ"}
      </h3>

      {/* แสดงข้อมูลเดิม */}
      <div className="space-y-2 text-sm">
        <p><span className="font-bold">Report ID:</span> {form.report_id || "-"}</p>
        <p><span className="font-bold">ผู้แจ้ง:</span> {form.created_by_username || "-"}</p>
        <p><span className="font-bold">วันที่แจ้ง:</span> {form.report_createdAt ? new Date(form.report_createdAt).toLocaleString("th-TH") : "-"}</p>
      </div>

      {/* หมวดหมู่ */}
      <label className="block mt-3 font-bold">หมวดหมู่:</label>
      <select
        className="select w-full border border-gray-300 rounded px-2 py-1 mt-1"
        value={form.report_category}
        onChange={(e) => setForm({ ...form, report_category: e.target.value })}
      >
        <option value="">-- เลือกหมวดหมู่ --</option>
        {categories
          .filter((c) => c.id !== "")
          .map((c) => (
            <option key={c.id} value={c.name}>
              {c.name}
            </option>
          ))}
      </select>

      {/* รายละเอียด */}
      <label className="block mt-3 font-bold">รายละเอียด:</label>
      <textarea
        className="textarea w-full border border-gray-300 rounded px-2 py-1 mt-1"
        placeholder="รายละเอียดปัญหา"
        value={form.report_detail}
        onChange={(e) => setForm({ ...form, report_detail: e.target.value })}
        rows={3}
      />

      {/* สถานะ */}
      <label className="block mt-3 font-bold">สถานะ:</label>
      <select
        className="select w-full border border-gray-300 rounded px-2 py-1 mt-1"
        value={form.report_status}
        onChange={(e) => setForm({ ...form, report_status: Number(e.target.value) })}
      >
        <option value={0}>รอดำเนินการ</option>
        <option value={1}>แก้แล้ว</option>
      </select>

      {/* ปุ่ม */}
      <div className="flex justify-end gap-3 pt-5">
        <button onClick={handleSave} className="btn btn-success">บันทึก</button>
        <button onClick={() => setEditingReport(null)} className="btn btn-error">ยกเลิก</button>
      </div>
    </div>
  </div>
)}

    </div>
  );
};

export default ReportTable;
