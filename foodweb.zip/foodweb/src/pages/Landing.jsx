import React, { useEffect, useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { AuthContext } from "../context/AuthContext"; // ยังคง import ไว้เผื่อใช้งานในอนาคต

const Landing = () => {
  const navigate = useNavigate();
  const { token } = useContext(AuthContext); // ยังคง useContext ไว้ เผื่อใช้ token สำหรับการเรียก API ที่ต้องการ
  const [hotRecipes, setHotRecipes] = useState([]);
  const [latest, setLatest] = useState([]);
  const [ranking, setRanking] = useState([]);
  const [tags, setTags] = useState([]);

  useEffect(() => {
    fetchRecipes();
    fetchTags();
    
    // ลบ token ออกจาก dependency array เพื่อให้ fetch ข้อมูลได้โดยไม่ต้องรอ token
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // กำหนดเป็น [] เพื่อให้เรียกเพียงครั้งเดียวเมื่อ component mount

  const Card = ({ item, onNavigate }) => (
  <div
    className="flex bg-pink-50 rounded shadow-sm p-2 items-start cursor-pointer hover:bg-pink-100 transition-colors"
    onClick={() => onNavigate(item._id)}
  >
    <img
      src={item.image ? `/uploads/${item.image}` : "/no-image.jpg"}
      alt={item.title}
      className="w-24 h-20 object-cover rounded"
    />
    <div className="ml-3 flex-1">
      <div className="font-medium text-sm">{item.title}</div>
      <div className="flex flex-wrap gap-1 mt-2">
                  {item.tags.map((id) => {
                    const tag = tags.find((t) => t.tag_id === id);
                    return (
                      <span
                        key={id}
                        className="badge badge-success badge-outline text-xs"
                      >
                        {tag ? tag.tag_name : id}
                      </span>
                    );
                  })}
                </div>
      <p className="text-sm text-yellow-600">
                  ⭐ คะแนนเฉลี่ย: {item.average ? item.average : "0"} / 5
      </p>
    </div>
  </div>
);

  const fetchRecipes = async () => {
    try {
      // ลบ headers ออก หรือกำหนดให้เป็น {} เพื่อไม่ส่ง Authorization header
      const res = await axios.get("http://localhost:3000/api/recipes", {}); // ไม่ส่ง headers หรือส่ง { headers: {} }
      const data = res.data || [];

      const hot = data.filter((r) => r.staring_status).slice(0, 6);
      setHotRecipes(hot.length ? hot : data.slice(0, 6));

      const sortedByDate = [...data].sort((a, b) => {
        const da = new Date(a.createdAt || a.updatedAt || 0).getTime();
        const db = new Date(b.createdAt || b.updatedAt || 0).getTime();
        return db - da;
      });
      setLatest(sortedByDate.slice(0, 6));

      const ranked = [...data]
        .filter((r) => r.rating || r.likes)
        .sort((a, b) => (b.rating || b.likes || 0) - (a.rating || a.likes || 0))
        .slice(0, 6);
      setRanking(ranked.length ? ranked : data.slice(0, 6));
    } catch (err) {
      console.error("Home fetchRecipes error:", err.message);
    }
  };

  const fetchTags = async () => {
    try {
      // ลบ headers ออก หรือกำหนดให้เป็น {} เพื่อไม่ส่ง Authorization header
      const res = await axios.get("http://localhost:3000/api/tag", {}); // ไม่ส่ง headers หรือส่ง { headers: {} }
      setTags(res.data || []);
    } catch (err) {
      console.error("Home fetchTags error:", err.message);
    }
  };

  return (
    <div className="p-6 max-w-screen-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">หน้าหลักอาหาร</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left: Hot recipes */}
        <section className="bg-white rounded shadow p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">เมนูยอดนิยม</h2>
            <span className="text-xs text-gray-500">เรียกดูล่าสุด</span>
          </div>
          <div className="space-y-3">
            {hotRecipes.map((r) => (
              <Card key={r._id} item={r} onNavigate={(id) => navigate(`/recipe/${id}`)} />
            ))}
          </div>
        </section>

        {/* Center: Ranking */}
        <section className="bg-white rounded shadow p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">อันดับเมนู</h2>
            <span className="text-xs text-gray-500">จัดอันดับตามคะแนน</span>
          </div>
          <div className="space-y-3">
            {ranking.map((r, idx) => (
              <div
                key={r._id}
                className="flex items-start bg-pink-50 rounded p-3 cursor-pointer hover:bg-pink-100 transition-colors"
                onClick={() => navigate(`/recipe/${r._id}`)}
              >
                <div className="w-8 h-8 rounded bg-pink-200 flex items-center justify-center font-bold mr-3">{idx + 1}</div>
                <div>
                  <div className="font-medium">{r.title}</div>
                  <p className="text-sm text-yellow-600">
                  ⭐ คะแนนเฉลี่ย: {r.average ? r.average : "0"} / 5
                </p>
                </div>
              </div>
            ))}
            <div className="h-24 rounded bg-pink-50" />
          </div>
        </section>

        {/* Right: Latest recipes */}
        <section className="bg-white rounded shadow p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">รายการล่าสุด</h2>
            <span className="text-xs text-gray-500">อัพเดตล่าสุด</span>
          </div>
          <div className="space-y-3">
            {latest.map((r) => (
              <Card key={r._id} item={r} onNavigate={(id) => navigate(`/recipe/${id}`)} />
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Landing;