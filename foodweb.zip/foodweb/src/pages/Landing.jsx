import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

const Landing = () => {
  const { token, role } = useContext(AuthContext);

  return (
    <div style={{ padding: "20px" }}>
      <h2>Welcome to My Website</h2>
      {!token && <p>กรุณา Login เพื่อเข้าใช้งานระบบ</p>}

      {token && role === "0" && <p>Hello World! นี่คือหน้า Member</p>}

      {token && role === "1" && (
        <p>คุณคือ Admin → ไปที่ Dashboard เพื่อจัดการข้อมูล</p>
      )}
    </div>
  );
};

export default Landing;
