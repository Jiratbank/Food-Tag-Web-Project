import { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import axios from "axios";

const MyRecipePage = () => {
  const { token, user_id } = useContext(AuthContext);
  const [recipes, setRecipes] = useState([]);
  const [tags, setTags] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    title: "",
    instructions: "",
    tags: [],
    staring_status: false,
  });
  const [ingredients, setIngredients] = useState([
    { name: "", quantity: "", unit: "" },
  ]);
  const [image, setImage] = useState(null);
  const [editId, setEditId] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [tagSearch, setTagSearch] = useState("");

  useEffect(() => {
    if (token) {
      fetchRecipes();
      fetchTags();
    }
  }, [token]);

  const fetchRecipes = async () => {
    try {
      const res = await axios.get("http://localhost:3000/api/recipes", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setRecipes(res.data.filter((r) => r.created_by === user_id));
    } catch (err) {
      console.error("Fetch error:", err.response?.data || err.message);
    }
  };

  const fetchTags = async () => {
    try {
      const res = await axios.get("http://localhost:3000/api/tag", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setTags(res.data);
    } catch (err) {
      console.error("Tag fetch error:", err.response?.data || err.message);
    }
  };

  // 🧂 ส่วนผสม dynamic
  const handleIngredientChange = (index, field, value) => {
    const newIngredients = [...ingredients];
    newIngredients[index][field] = value;
    setIngredients(newIngredients);
  };

  const addIngredient = () => {
    setIngredients([...ingredients, { name: "", quantity: "", unit: "" }]);
  };

  const removeIngredient = (index) => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  // 📋 จัดการช่องทั่วไป
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm({
      ...form,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  const handleFile = (e) => setImage(e.target.files[0]);

  // 💾 บันทึกสูตร
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const data = new FormData();
      Object.keys(form).forEach((key) => {
        if (key === "tags") {
          form.tags.forEach((t) => data.append("tags", t));
        } else {
          data.append(key, form[key]);
        }
      });
      data.append("ingredients", JSON.stringify(ingredients));
      if (image) data.append("image", image);

      if (editId) {
        await axios.put(`http://localhost:3000/api/recipes/${editId}`, data, {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        });
      } else {
        await axios.post("http://localhost:3000/api/recipes", data, {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        });
      }

      setForm({
        title: "",
        instructions: "",
        tags: [],
        staring_status: false,
      });
      setIngredients([{ name: "", quantity: "", unit: "" }]);
      setImage(null);
      setEditId(null);
      setShowForm(false);
      fetchRecipes();
    } catch (err) {
      console.error("Save error:", err.response?.data || err.message);
    }
  };

  const handleEdit = (r) => {
    setForm({
      title: r.title,
      instructions: r.instructions,
      tags: r.tags || [],
      staring_status: r.staring_status || false,
    });
    try {
      setIngredients(
        Array.isArray(r.ingredients)
          ? r.ingredients
          : JSON.parse(r.ingredients || "[]")
      );
    } catch {
      setIngredients([{ name: "", quantity: "", unit: "" }]);
    }
    setEditId(r._id);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm("ลบสูตรนี้จริงหรือไม่?")) {
      await axios.delete(`http://localhost:3000/api/recipes/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchRecipes();
    }
  };

  const filteredRecipes = recipes.filter((r) =>
    r.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-900 p-6 rounded-lg">
      <h2 className="text-3xl font-bold mb-6 text-center">สูตรอาหารของฉัน 🍳</h2>

      {/* ค้นหา + ปุ่มเพิ่มสูตร */}
      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-3">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <label>ค้นหา :</label>
          <input
            type="text"
            placeholder="ค้นหาสูตรอาหาร..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input border border-gray-300 rounded-lg py-2 w-full sm:w-1/2"
          />
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="btn btn-info btn-outline"
        >
          + เพิ่มสูตร
        </button>
      </div>

      {/* Popup ฟอร์มเพิ่ม/แก้ไข */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 text-gray-900">
          <div className="bg-gray-100 rounded-lg shadow-lg p-6 w-1/2 max-h-[90vh] overflow-y-auto">
            <h3 className="text-xl font-semibold mb-4 text-center">
              {editId ? "แก้ไขสูตรอาหาร" : "เพิ่มสูตรใหม่"}
            </h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <legend className="text-gray-800">* ชื่อสูตร</legend>
              <input
                type="text"
                name="title"
                placeholder="ชื่อสูตร"
                value={form.title}
                onChange={handleChange}
                required
                className="input w-full border border-gray-300 rounded px-2 py-1 "
              />

              <legend className="text-gray-800">* ส่วนผสม</legend>
              {ingredients.map((ing, index) => (
                <div key={index} className="flex gap-2 mb-2">
                  <input
                    type="text"
                    placeholder="ชื่อวัตถุดิบ"
                    value={ing.name}
                    onChange={(e) =>
                      handleIngredientChange(index, "name", e.target.value)
                    }
                    className="input input-bordered w-1/2"
                    required
                  />
                  <input
                    type="number"
                    placeholder="จำนวน"
                    value={ing.quantity}
                    onChange={(e) =>
                      handleIngredientChange(index, "quantity", e.target.value)
                    }
                    className="input input-bordered w-1/4"
                    required
                  />
                  <select
                    value={ing.unit}
                    onChange={(e) =>
                      handleIngredientChange(index, "unit", e.target.value)
                    }
                    className="select select-bordered w-1/4"
                    required
                  >
                    <option value="">หน่วย</option>
                    <option value="กรัม">กรัม</option>
                    <option value="ช้อนโต๊ะ">ช้อนโต๊ะ</option>
                    <option value="ถ้วย">ถ้วย</option>
                    <option value="ลูก">ลูก</option>
                    <option value="ชิ้น">ชิ้น</option>
                  </select>
                  {ingredients.length > 1 && (
                    <button
                      type="button"
                      className="btn btn-error btn-sm"
                      onClick={() => removeIngredient(index)}
                    >
                      🗑
                    </button>
                  )}
                </div>
              ))}
              <button
                type="button"
                onClick={addIngredient}
                className="btn btn-outline btn-sm"
              >
                + เพิ่มส่วนผสม
              </button>

              <legend className="text-gray-800">* วิธีทำ</legend>
              <textarea
                name="instructions"
                placeholder="วิธีทำ"
                value={form.instructions}
                onChange={handleChange}
                required
                className="textarea w-full border border-gray-300 rounded px-2 py-1 mt-2"
              />

              <label className="block text-sm">
                <input
                  type="checkbox"
                  name="staring_status"
                  checked={form.staring_status}
                  onChange={handleChange}
                  className="mr-2 accent-green-500"
                />
                ต้องการให้สูตรนี้สาธารณะ
              </label>

              {/* Tag select */}
              <div>
                <legend className="text-gray-800">เลือกแท็ก (สูงสุด 5 อัน)</legend>
                <input
                  type="text"
                  placeholder="ค้นหาแท็ก..."
                  value={tagSearch}
                  onChange={(e) => setTagSearch(e.target.value)}
                  className="input w-full border border-gray-300 rounded px-2 py-1 mb-2"
                />
                <div className="flex flex-wrap gap-2">
                  {tags
                    .filter((t) =>
                      t.tag_name.toLowerCase().includes(tagSearch.toLowerCase())
                    )
                    .map((t) => (
                      <div
                        key={t.tag_id}
                        onClick={() => {
                          if (form.tags.includes(t.tag_id)) {
                            setForm({
                              ...form,
                              tags: form.tags.filter((id) => id !== t.tag_id),
                            });
                          } else if (form.tags.length < 5) {
                            setForm({
                              ...form,
                              tags: [...form.tags, t.tag_id],
                            });
                          } else {
                            alert("เลือกแท็กได้สูงสุด 5 อัน");
                          }
                        }}
                        className={`px-3 py-1 border rounded-full cursor-pointer ${
                          form.tags.includes(t.tag_id)
                            ? "bg-green-200 border-green-500"
                            : "bg-gray-100 hover:bg-gray-200"
                        }`}
                      >
                        {t.tag_name}
                      </div>
                    ))}
                </div>
              </div>

              <legend className="text-gray-800">รูปภาพประกอบ</legend>
              <input
                type="file"
                accept="image/*"
                onChange={handleFile}
                className="input w-full border border-gray-300 rounded px-2 py-1"
              />

              <div className="flex justify-end gap-3 pt-3">
                <button type="submit" className="btn btn-success">
                  {editId ? "อัปเดตสูตร" : "บันทึกสูตร"}
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="btn btn-error ml-2"
                >
                  ยกเลิก
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* แสดงสูตรเป็น Card */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
        {filteredRecipes.length === 0 ? (
          <p className="col-span-full text-center text-gray-500">
            ไม่พบสูตรอาหาร
          </p>
        ) : (
          filteredRecipes.map((r) => (
            <div
              key={r._id}
              className="bg-white dark:bg-gray-800 rounded-2xl shadow-md hover:shadow-xl overflow-hidden border border-gray-200 dark:border-gray-700 transition-all duration-200"
            >
              <div className="relative">
                {r.image ? (
                  <img
                    src={`/uploads/${r.image}`}
                    alt={r.title}
                    className="w-full h-48 object-cover"
                  />
                ) : (
                  <div className="w-full h-48 bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-gray-500">
                    ไม่มีรูป
                  </div>
                )}
                <span
                  className={`absolute top-3 right-3 px-3 py-1 text-xs font-semibold rounded-full shadow ${
                    r.staring_status
                      ? "bg-green-500 text-white"
                      : "bg-gray-500 text-white"
                  }`}
                >
                  {r.staring_status ? "Public" : "Private"}
                </span>
              </div>

              <div className="p-4 flex flex-col gap-2">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                  {r.title}
                </h3>
                <div className="flex flex-wrap gap-2">
                  {r.tags && r.tags.length > 0 ? (
                    r.tags.map((id) => {
                      const tag = tags.find((t) => t.tag_id === id);
                      return (
                        <span
                          key={id}
                          className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 text-xs px-2 py-1 rounded-full"
                        >
                          {tag ? tag.tag_name : id}
                        </span>
                      );
                    })
                  ) : (
                    <span className="text-gray-400 text-sm">ไม่มีแท็ก</span>
                  )}
                </div>

                <p className="text-sm text-gray-600 dark:text-gray-300">
                  <strong>ส่วนผสม:</strong>{" "}
                  {Array.isArray(r.ingredients)
                    ? r.ingredients
                        .map(
                          (i) =>
                            `${i.name} ${i.quantity}${i.unit ? " " + i.unit : ""}`
                        )
                        .join(", ")
                    : r.ingredients}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-2">
                  <strong>วิธีทำ:</strong> {r.instructions}
                </p>

                <div className="flex justify-end gap-2 mt-4">
                  <button
                    onClick={() => handleEdit(r)}
                    className="btn btn-info btn-outline"
                  >
                    แก้ไข
                  </button>
                  <button
                    onClick={() => handleDelete(r._id)}
                    className="btn btn-error btn-outline"
                  >
                    ลบ
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default MyRecipePage;
