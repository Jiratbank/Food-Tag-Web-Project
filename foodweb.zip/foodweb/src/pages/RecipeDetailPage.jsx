import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import axios from "axios";

const RecipeDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { token ,user_id} = useContext(AuthContext);
  const [recipe, setRecipe] = useState(null);
  const [tags, setTags] = useState([]);

  const [ratings, setRatings] = useState([]);
  const [average, setAverage] = useState(0);
  const [score, setScore] = useState(5);
  const [comment, setComment] = useState("");

  useEffect(() => {
    fetchRecipe();
    fetchTags();
    fetchRatings();
  }, [id]);

  const fetchRecipe = async () => {
    try {
      const res = await axios.get(`http://localhost:3000/api/recipes/${id}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      setRecipe(res.data);
      
    } catch (err) {
      console.error("Fetch error:", err.message);
    }
  };

  const fetchTags = async () => {
    try {
      const res = await axios.get("http://localhost:3000/api/tag",{
        headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
      setTags(res.data);
    } catch (err) {
      console.error("Tag fetch error:", err.message);
    }
  };

  // ดึงคะแนนทั้งหมด
const fetchRatings = async () => {
  try {
    const res = await axios.get(`http://localhost:3000/api/recipes/${id}/ratings`);
    setRatings(res.data.ratings);
    setAverage(res.data.average);
    console.log("Fetched ratings:", res.data);
  } catch (err) {
    console.error("Ratings fetch error:", err.message);
  }
};

// ส่งความคิดเห็น
const submitRating = async () => {
  try {
    await axios.post(
      `http://localhost:3000/api/recipes/${id}/rate`,
      { score, comment },
      { headers: { Authorization: `Bearer ${token}` } }
    );
    setComment("");
    fetchRatings();
  } catch (err) {
    console.error("Submit rating error:", err.message);
  }
};

const deleteRating = async (ratingId) => {
  if (!window.confirm("ต้องการลบความคิดเห็นนี้ใช่ไหม?")) return;
  try {
    await axios.delete(
      `http://localhost:3000/api/recipes/${id}/rate/${ratingId}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    fetchRatings(); // refresh list
  } catch (err) {
    console.log("Delete rating error:", err.message);
  }
};


  if (!recipe)
    return (
      <div className="flex justify-center items-center h-screen text-gray-500">
        กำลังโหลดข้อมูล...
      </div>
    );

  return (
    <div className="min-h-screen bg-base-200 py-8 px-6">
      <button
        className="btn btn-outline btn-sm mb-4"
        onClick={() => navigate(-1)}
      >
        ← กลับ
      </button>

      <div className="card bg-base-100 shadow-xl max-w-5xl mx-auto">
        <figure>
          <img
            src={recipe.image ? `/uploads/${recipe.image}` : "/no-image.jpg"}
            alt={recipe.title}
            className="w-full h-80 object-cover"
          />
        </figure>
        <div className="card-body">
          <h2 className="card-title text-3xl">{recipe.title}</h2>

          <div className="flex flex-wrap gap-2">
            {recipe.tags.map((id) => {
              const tag = tags.find((t) => t.tag_id === id);
              return (
                <div key={id} className="badge badge-outline badge-success">
                  {tag ? tag.tag_name : id}
                </div>
              );
            })}
          </div>

          <p className="mt-3 text-gray-600">
            👨‍🍳 ผู้สร้าง: {recipe.created_by_username || "ไม่ทราบ"}
          </p>
          <p className="text-sm text-gray-400">
            วันที่สร้าง: {new Date(recipe.createdAt).toLocaleDateString("th-TH")}
          </p>

          <div className="divider" />

          <h3 className="font-bold text-lg">🥦 ส่วนผสม</h3>
          <p className="text-sm text-gray-600 dark:text-gray-300">
                  <strong>ส่วนผสม:</strong>{" "}
                  {Array.isArray(recipe.ingredients)
                    ? recipe.ingredients
                        .map(
                          (i) =>
                            `${i.name} ${i.quantity}${i.unit ? " " + i.unit : ""}`
                        )
                        .join(", ")
                    : recipe.ingredients}
                </p>

          <h3 className="font-bold text-lg mt-4">🍳 วิธีทำ</h3>
          <p className="whitespace-pre-line">{recipe.instructions}</p>
          <div className="divider" />
<h3 className="font-bold text-lg">⭐ คะแนนเฉลี่ย: {average} / 5</h3>

{/* ฟอร์มให้คะแนน */}
{token && (
  <div className="mt-4">
    <label className="block font-medium">ให้คะแนน</label>

    {/* ⭐ Rating Stars */}
    <div className="rating rating-lg mt-2">
      {[1, 2, 3, 4, 5].map((s) => (
        <input
          key={s}
          type="radio"
          name="rating"
          className="mask mask-star-2 bg-yellow-400"
          checked={score === s}
          onChange={() => setScore(s)}
        />
      ))}
    </div>

    {/* 💬 ช่องคอมเมนต์ */}
    <textarea
      className="textarea textarea-bordered w-full mt-3"
      placeholder="แสดงความคิดเห็น..."
      value={comment}
      onChange={(e) => setComment(e.target.value)}
    ></textarea>

    {/* 📤 ปุ่มส่ง */}
    <button className="btn btn-success mt-3" onClick={submitRating}>
      ส่งความคิดเห็น
    </button>
  </div>
)}

{/* แสดงความคิดเห็น */}
<div className="mt-6">
  <h4 className="font-bold mb-2">💬 ความคิดเห็นทั้งหมด</h4>
  {ratings.length === 0 ? (
    <p className="text-gray-500">ยังไม่มีความคิดเห็น</p>
  ) : (
    ratings.map((r, i) => (
      <div
        key={i}
        className="border-b border-gray-300 py-2 flex justify-between items-start"
      >
        <div>
          <p className="font-semibold">
            {r.username || `user#${r.user_id}`} — ⭐ {r.score}/5
          </p>
          <p>{r.comment}</p>
        </div>

        {/* ปุ่มลบเฉพาะเจ้าของคอมเมนต์ */}
        {r.user_id === user_id && (
          <button
            className="btn btn-xs btn-error text-white"
            onClick={() => deleteRating(r._id)}
          >
            ลบ
          </button>
        )}
      </div>
    ))
  )}
</div>

        </div>
      </div>
    </div>
  );
};

export default RecipeDetailPage;
