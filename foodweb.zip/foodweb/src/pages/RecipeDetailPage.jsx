import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import axios from "axios";

const RecipeDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { token} = useContext(AuthContext);
  const [recipe, setRecipe] = useState(null);
  const [tags, setTags] = useState([]);

  useEffect(() => {
    fetchRecipe();
    fetchTags();
  }, [id]);

  const fetchRecipe = async () => {
    try {
      const res = await axios.get(`http://localhost:3000/api/recipes/${id}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      setRecipe(res.data);
      console.log(res.data);
    } catch (err) {
      console.error("Fetch error:", err.message);
    }
  };

  const fetchTags = async () => {
    try {
      const res = await axios.get("http://localhost:3000/api/tag",{
        headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
      setTags(res.data);
    } catch (err) {
      console.error("Tag fetch error:", err.message);
    }
  };


  if (!recipe)
    return (
      <div className="flex justify-center items-center h-screen text-gray-500">
        กำลังโหลดข้อมูล...
      </div>
    );

  return (
    <div className="min-h-screen bg-base-200 py-8 px-6">
      <button
        className="btn btn-outline btn-sm mb-4"
        onClick={() => navigate(-1)}
      >
        ← กลับ
      </button>

      <div className="card bg-base-100 shadow-xl max-w-5xl mx-auto">
        <figure>
          <img
            src={recipe.image ? `/uploads/${recipe.image}` : "/no-image.jpg"}
            alt={recipe.title}
            className="w-full h-80 object-cover"
          />
        </figure>
        <div className="card-body">
          <h2 className="card-title text-3xl">{recipe.title}</h2>

          <div className="flex flex-wrap gap-2">
            {recipe.tags.map((id) => {
              const tag = tags.find((t) => t.tag_id === id);
              return (
                <div key={id} className="badge badge-outline badge-success">
                  {tag ? tag.tag_name : id}
                </div>
              );
            })}
          </div>

          <p className="mt-3 text-gray-600">
            👨‍🍳 ผู้สร้าง: {recipe.created_by_username || "ไม่ทราบ"}
          </p>
          <p className="text-sm text-gray-400">
            วันที่สร้าง: {new Date(recipe.createdAt).toLocaleDateString("th-TH")}
          </p>

          <div className="divider" />

          <h3 className="font-bold text-lg">🥦 ส่วนผสม</h3>
          <p className="text-sm text-gray-600 dark:text-gray-300">
                  <strong>ส่วนผสม:</strong>{" "}
                  {Array.isArray(recipe.ingredients)
                    ? recipe.ingredients
                        .map(
                          (i) =>
                            `${i.name} ${i.quantity}${i.unit ? " " + i.unit : ""}`
                        )
                        .join(", ")
                    : recipe.ingredients}
                </p>

          <h3 className="font-bold text-lg mt-4">🍳 วิธีทำ</h3>
          <p className="whitespace-pre-line">{recipe.instructions}</p>

        
        </div>
      </div>
    </div>
  );
};

export default RecipeDetailPage;
