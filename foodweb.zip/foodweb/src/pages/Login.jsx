import { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Login = () => {
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: "", password: "" });
  const [error, setError] = useState("");


  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleCancel = () => {
    navigate("/");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const res = await axios.post("http://localhost:3000/api/auth/login", form);

      // backend ส่งกลับ: { token, role, username, image }
      const { token, role, username, image ,user_id } = res.data;

      // ส่งค่าครบให้ AuthContext
      login(token, role, username, image ,user_id );


      alert("Login สำเร็จแล้ว!");
      console.log("File uploaded:", username);  // 👈 debug
         
      navigate("/"); // กลับไปหน้า Landing
    } catch (err) {
      console.error(err);
      setError("Login failed");
    }
  };

  return (
    
    <div className="card card-border bg-base-100 border-base-300 text-base-content p-4 rounded rounded-xl shadow-lg max-w-md mx-auto mt-10">
      
      <h2 className="text-3xl font-bold mt-2 text-center">Login</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <form onSubmit={handleSubmit} className="flex flex-col gap-2 justify-center items-center mt-5 ">
        <fieldset className="fieldset">
          <legend className="fieldset-legend text-xl">Username</legend>
          <label className="input validator">
            <svg className="h-[1em] opacity-50" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <g
                  strokeLinejoin="round"
                  strokeLinecap="round"
                  strokeWidth="2.5"
                  fill="none"
                  stroke="currentColor"
                >
                  <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
                  <circle cx="12" cy="7" r="4"></circle>
                </g>
              </svg>
              
          <input className="input-md px-5 py-1"
                type="text"
                name="username"
                placeholder="Username"
                pattern="[A-Za-z][A-Za-z0-9\-]*"
                title="Only letters, numbers or dash"
                value={form.username}
                onChange={handleChange}
                required/>
          </label>
          <legend className="fieldset-legend text-xl">Password</legend>
          <label className="input validator">
            <svg className="h-[1em] opacity-50" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <g
                  strokeLinejoin="round"
                  strokeLinecap="round"
                  strokeWidth="2.5"
                  fill="none"
                  stroke="currentColor"
                >
                  <path
                    d="M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z"
                  ></path>
                  <circle cx="16.5" cy="7.5" r=".5" fill="currentColor"></circle>
                </g>
              </svg>
          <input className="input-md px-5 py-1"
                type="password"
                name="password"
                placeholder="Password"
                value={form.password}
                onChange={handleChange}
                required/>
          </label>
        </fieldset>
        <br />
        <div className="p-2 text-center">
            <button className="btn btn-success"
            type="submit">Login</button>
            <button
            className="btn btn-error m-2" 
            type="button" 
            onClick={handleCancel}
          >Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default Login;
