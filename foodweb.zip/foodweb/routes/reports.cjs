const express = require("express");
const router = express.Router();
const Report = require("../models/Report.cjs");
const jwt = require("jsonwebtoken");
const mongoose = require("mongoose");

// ตรวจสอบ token
const verifyToken = (req, res, next) => {
  const authHeader = req.headers["authorization"];
  if (!authHeader) return res.status(401).json({ message: "No token provided" });

  const token = authHeader.split(" ")[1];
  jwt.verify(token, "your_jwt_secret", (err, decoded) => {
    if (err) return res.status(403).json({ message: "Invalid token" });
    req.user = decoded;
    next();
  });
};

// CREATE (Admin add report)
router.post("/", verifyToken, async (req, res) => {
  try {
    const { report_category, report_detail, report_status } = req.body;

    const report = new Report({
      report_category,
      report_detail,
      report_status: report_status === "1" || report_status === 1,
      created_by: req.user.user_id, // เอา user_id จาก token
    });

    await report.save();
    res.status(201).json(report);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Create report failed" });
  }
});

// READ all
router.get("/", verifyToken, async (req, res) => {
  try {
    const reports = await Report.find();

    const users = await mongoose
          .model("User")
          .find({}, "user_id username")
          .lean();
    
        // map user_id → username
        const reportsWithUser = reports.map((r) => {
          const user = users.find((u) => u.user_id === r.created_by);
          return {
            ...r.toObject(),
            created_by_username: user ? user.username : `user#${r.created_by}`,
          };
        });
    
    res.json(reportsWithUser);  
  } catch (err) {
    res.status(500).json({ message: "Fetch reports failed" });
  }
});

// UPDATE
router.put("/:id", verifyToken, async (req, res) => {
  if (req.user.role !== "1") return res.status(403).json({ message: "Admin only" });
  try {
    await Report.findByIdAndUpdate(req.params.id, req.body);
    res.json({ message: "Report updated" });
  } catch (err) {
    res.status(500).json({ message: "Update report failed" });
  }
});

// DELETE
router.delete("/:id", verifyToken, async (req, res) => {
  if (req.user.role !== "1") return res.status(403).json({ message: "Admin only" });
  try {
    await Report.findByIdAndDelete(req.params.id);
    res.json({ message: "Report deleted" });
  } catch (err) {
    res.status(500).json({ message: "Delete report failed" });
  }
});

module.exports = router;
